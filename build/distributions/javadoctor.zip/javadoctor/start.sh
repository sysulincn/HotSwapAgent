#!/bin/sh
java -cp "*:lib/*" main.JavaDoctor "$@"